Autonomous Agent Launcher (Windows)

How to use:
1. Double-click `AutonomousAgent.exe` to run the agent.
2. All logs will be saved to `agent.log`.
3. To launch silently at startup, add `launch_agent.bat` to Task Scheduler.
4. To view logs live, open your browser to: http://localhost:8000/stream
