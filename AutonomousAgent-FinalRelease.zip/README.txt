AutonomousAgent (Windows EXE)

✅ Agent runs from system tray with options to Start/Stop
🌐 View logs in real-time at http://localhost:8000/stream
🔁 Auto-updates from configured update URL if enabled in .env
🗂 To start: Double-click AutonomousAgent.exe

Tray Options:
- Start Agent
- Stop Agent
- View Logs
- Open Dashboard
- Quit
